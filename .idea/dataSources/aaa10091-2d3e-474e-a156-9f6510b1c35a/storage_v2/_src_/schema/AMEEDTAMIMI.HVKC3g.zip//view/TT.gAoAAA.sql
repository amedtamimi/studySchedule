create view TT as
select ename,sal from emp 
    where sal >1000
/

