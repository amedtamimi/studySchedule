create view SAL_EMP as
select EMPLOYEE_ID,concat(FIRST_NAME,LAST_NAME) name,SALARY from EMPLOYEES
/

