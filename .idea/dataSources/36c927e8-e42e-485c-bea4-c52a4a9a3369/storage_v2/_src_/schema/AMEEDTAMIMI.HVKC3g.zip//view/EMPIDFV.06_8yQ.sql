create view EMPIDFV as
select EMPLOYEE_ID from SAL_EMP
/

